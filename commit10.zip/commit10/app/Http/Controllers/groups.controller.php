<?php

namespace App\Http\Controllers\Api;

        $groups = groups::create([
        $g = groups::create([
            'nama' => $request->nama,
            'no_tlp' => $request->no_tlp,
            'alamat' => $request->alamat,
@@ -88,22 +88,16 @@ public function show($id)
use App\Models\Groups;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GroupsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    public function index()
    {
        $request->validate([
            'nama' => 'required|unique:groups|max:255',
            'no_tlp' => 'required|numeric',
            'alamat' => 'required',
            'groups_id' => 'required'
        ]);
        $g = groups::find($id)->update([
        $groups = groups::find($id)->update([
            'nama' => $request->nama,
            'no_tlp' => $request->no_tlp,
            'alamat' => $request->alamat,
            'groups_id' => $request->groups_id
        ]);
        $groups = Groups::orderBy('id', 'desc')->paginate(3);

        return response()->json([
            'success' => true,
            'message' => 'Post Updated',
            'data' => $g
            'message' => 'Data Teman berhasil di rubah',
            'data' => $group
            'message'    => 'Daftar data grup teman',
            'data'       => $groups
        ], 200);
    }

@@ -115,11 +109,11 @@ public function update(Request $request, $id)
    /**
     * Store a newly created resource in storage.
     * 
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    public function store (Request $request)
    {
        $cek = groups::find($id)->delete();
        $group = groups::find($id)->delete();
        return response()->json([
        $request->validate([
            'id' => 'required|unique:friends|max:255',
            'name' =>'required|numeric',
            'description' => 'required',
        ]);

        $groups = Groups::create([
            'id' => $request->id,
            'name' => $request->name,
            'description'=> $request->description,

        ]);
            if ($groups) {
                return response()->json([
                    'success' => true,
                    'message'    => 'grup Berhasil di tambahkan',
                    'data'       => $groups
                ], 200);
            }else {
                return response()->json([
                    'success' => false,
                    'message'    => 'group Gagal Ditambahkan ',
                    'data'       => $groups
                ], 409); 
            }
    }
    public function show ($id)
    {
        $group = Groups::where('id',$id)->first();
        return response()-> json([
            'success' => true,
            'message' => 'Post Updated',
            'data'    => $cek
            'message' => 'Data Teman Berhasil di hapus',
            'data'    => $group
        ], 200);
            'message'    => 'Detail Data group ',
            'data'       => $group
        ], 200); 
    }

        public function update(Request $request, $id)
        {


            $group = Groups::find($id)->update([
                'id' => $request->id,
                'name' => $request->name,
                'description' => $request->description
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Data grup telah berhasil di rubah',
                'data'    => $group
            ], 200);
        }
        public function destroy($id)
        {
            $group = Groups::find($id)->delete();
            return response()->json([
                'success' => true,
                'message' => 'data grup berhasil di hapus',
                'data'    => $group
            ], 200);
        }

    }
} 